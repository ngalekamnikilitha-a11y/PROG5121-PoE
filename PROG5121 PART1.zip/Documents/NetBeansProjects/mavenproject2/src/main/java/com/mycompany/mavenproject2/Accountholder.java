/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

/**
 *
 * @author ngale
 */
import java.util.regex.Pattern;

public class AccountCreator {
    public static void main(String[] args) {
        String username = "mni_1";
        String password = "Pass123!";
        String phoneNumber = "0821234567";

        System.out.println(checkUsername(username));
        System.out.println(checkPassword(password));
        System.out.println(checkPhoneNumber(phoneNumber));
    }

    static String checkUsername(String username) {
        String regex = "^[^_]{1,4}_[^_]*$";
        if (Pattern.matches(regex, username) && username.length() <= 5) {
            return "Username successfully captured.";
        } else {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
    }

    static String checkPassword(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        if (Pattern.matches(regex, password)) {
            return "Password successfully captured.";
        } else {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
    }

    static String checkPhoneNumber(String phoneNumber) {
        String regex = "^0\\d{9}$";
        if (Pattern.matches(regex, phoneNumber)) {
            return "Phone number is valid.";
        } else {
            return "Invalid SA phone number.";
        }
    }
}
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;

/**
 *
 * @author ngaleka mnikilitha
 */

import java.util.Scanner;
import java.util.regex.Pattern;

public class Registration {
    private static String savedUsername = "";
    private static String savedPassword = "";

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Create account
        createAccount(input);
        
        // Login prompt
        loginPrompt(input);

        input.close();
    }

    private static void createAccount(Scanner input) {
        String username = "";
        String password = "";
        String phoneNumber = "";

        // Loop until a valid username is entered
        while (true) {
            System.out.println("Enter username (1-4 letters followed by '_' and at least 1 more character): ");
            username = input.nextLine().trim();
            boolean ok = isUsernameValid(username);
            System.out.println(ok ? "Username successfully captured." : "Username is not correctly formatted, please ensure the pattern: 1-4 letters + '_' + at least one more letter.");
            if(ok) {
                savedUsername = username;
                break;
            }
            
            
        }

        // Loop until a valid password is entered
        while (true) {
            System.out.println("Enter password (at least 8 characters, including an uppercase letter, a number, and a special character): ");
            password = input.nextLine();
            boolean ok = isPasswordValid(password);
            System.out.println(ok ? "Password successfully captured." : "Password is not correctly formatted, ensure it has at least eight characters, one capital letter, one number, and one special character.");
            if(ok){
                savedPassword = password;
                break;
            }
            
            
            
        }

        // Loop until a valid phone number is entered
        while (true) {
            System.out.println("Enter phone number (10 digits starting with 0): ");
            phoneNumber = input.nextLine().trim();
            boolean ok = isPhoneNumberValid(phoneNumber);
            System.out.println(ok ? "Phone number is valid." : "Invalid SA phone number, it should have 10 digits and start with '0' followed by 6/7/8.");
            if (ok){
                break;
            }
        
        }

        // Account creation success message
        System.out.println("Account created successfully with the following details:");
        System.out.println("Username: " + savedUsername);
        // Consider hiding password in production
        System.out.println("Password: " + savedPassword);
        System.out.println("Phone number: " + phoneNumber);
    }

    private static void loginPrompt(Scanner input) {
        String usernameAttempt;
        String passwordAttempt;
        
        // Loop until valid login
        while (true) {
            System.out.println("Login to your account:");
            System.out.print("Enter username: ");
            usernameAttempt = input.nextLine();
            System.out.print("Enter password: ");
            passwordAttempt = input.nextLine();
            
            if (usernameAttempt.equals(savedUsername) && passwordAttempt.equals(savedPassword)) {
                System.out.println("Login successful. Welcome!");
                break; // Exit the loop on successful login
            } else {
                System.out.println("Invalid username or password. Please try again.");
            }
        }
    }

    public static boolean isUsernameValid(String username) {
        String regex = "^[a-zA-Z]{1,4}_[^_]+$"; // Username format
       return (Pattern.matches(regex, username));
    }

    public static boolean isPasswordValid(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$"; // Password format
       return (Pattern.matches(regex, password));
        
            
        }
            
           
    public static boolean isPhoneNumberValid(String phoneNumber) {
        String regex = "^0(6|7|8)\\d{8}$"; // South African phone number format
       return (Pattern.matches(regex, phoneNumber));
    }

}


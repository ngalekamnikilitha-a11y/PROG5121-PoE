
import java.util.Scanner;
import java.util.regex.Pattern;

public class ChatUser {
    private static String savedUsername = "";
    private static String savedPassword = "";
    private static String savedFirstname = "";
    private static String savedLastname = "";

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        
        createAccount(input);
        
        
        loginPrompt(input);

        input.close();
    }

    private static void createAccount(Scanner input) {
        String username = "";
        String firstname = "";
        String lastname = "";
        String password = "";
        String phoneNumber = "";

        
        while (true) {
            System.out.println("Enter Username (1-4 letters followed by '_' and at least 1 more character): ");
            username = input.nextLine();
            String usernameValidation = checkUsername(username);
            System.out.println(usernameValidation);
            
            
            if (usernameValidation.startsWith("Username successfully")) {
                savedUsername = username;
                break;
            }
        }
        
        while(true){
            System.out.println("Enter firstname: ");
            firstname = input.nextLine();
            String firstnameValidation = checkFirstname(firstname);
            System.out.println(firstnameValidation);
            
            if (firstnameValidation.startsWith("firstname successful")) {
                savedFirstname = firstname;
                break;
            }
        }
        
        while(true){
            System.out.println("Enter your lastname: ");
            lastname = input.nextLine();
            String lastnameValidation = checkLastname(lastname);
            System.out.println(lastnameValidation);
            
            if (lastnameValidation.startsWith("lastname successful")){
                savedLastname = lastname;
                break;
            }
        }

        
        while (true) {
            System.out.println("Enter password (at least 8 characters, including an uppercase letter, a number, and a special character): ");
            password = input.nextLine();
            String passwordValidation = checkPassword(password);
            System.out.println(passwordValidation);
            if (passwordValidation.startsWith("Password successfully")) {
                savedPassword = password; 
                break;
            }
        }

        
        while (true) {
            System.out.println("Enter phone number (10 digits starting with 07, 06,or 08): ");
            phoneNumber = input.nextLine();
            String phoneValidation = checkPhoneNumber(phoneNumber);
            System.out.println(phoneValidation);
            if (phoneValidation.startsWith("Phone number is valid")) {
                break;
            }
        }

        
        System.out.println("Account has been successfully created with the following details:");
        System.out.println("Username: " + savedUsername);
        System.out.println("Fisrtname: " + savedFirstname);
        System.out.println("Lastname: " + savedLastname);
        System.out.println("Password: " + savedPassword);
        System.out.println("Phone number: " + phoneNumber);
    }

    private static void loginPrompt(Scanner input) {
        String usernameAttempt;
        String passwordAttempt;
        
        
        while (true) {
            System.out.println("Login to your account:");
            System.out.print("Enter username: ");
            usernameAttempt = input.nextLine();
            System.out.print("Enter password: ");
            passwordAttempt = input.nextLine();
            
            if (usernameAttempt.equals(savedUsername) && passwordAttempt.equals(savedPassword)) {
                System.out.println("Login successful. Welcome User!");
                break;
            } else {
                System.out.println("Incorrect username or password. Please try again.");
            }
        }
    }

    public static String checkUsername(String username) {
        String regex = "^[a-zA-Z]{1,4}_[^_]+$"; 
        if (Pattern.matches(regex, username)) {
            return "Username is successful.";
        } else {
            return "Username is not successful; please ensure that your username contains an underscore and the pattern is 1-4 letters + '_' + at least 1 more character.";
        }
    } 
    
    
    public static String checkFirstname(String firstname) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)$";
        if (Pattern.matches(regex, firstname)){
            return "Firstname is successful";
            
        }
        else {
            return "Firstname is not successful";
        }
    }
    
    public static String checkLastname(String lastname) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)$";
        if (Pattern.matches(regex, lastname )){
            return "Lastname is successful";
            
        }
        else {
            return "Lastname is not successful";
        }
    }

    public static String checkPassword(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$"; 
        if (Pattern.matches(regex, password)) {
            return "Password is successful.";
        }
        
        else {
            return "Password is not successful; ensure it has at least eight characters, one capital letter, one number, and one special character.";
        }
    }

    public static String checkPhoneNumber(String phoneNumber) {
        String regex = "^0(6|7|8)\\d{8}$"; 
        if (Pattern.matches(regex, phoneNumber)) {
            return "Phone number is correct.";
        } else {
            return "Incorrect SA phone number; it should have 10 digits and start with either'07, 06, or 08'.";
        }
    }
}


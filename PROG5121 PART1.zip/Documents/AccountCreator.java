/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
import java.util.regex.Pattern;

public class AccountCreator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        
        System.out.println("Enter username: ");
        String username = input.nextLine();
        
        System.out.println("Enter password: ");
        String password = input.nextLine();
        
        System.out.println("Enter phoneNumber: ");
        String phoneNumber = input.nextLine();

        System.out.println(checkUsername(username));
        System.out.println(checkPassword(password));
        System.out.println(checkPhoneNumber(phoneNumber));
    }

    public static String checkUsername(String username) {
        String regex = "^[^_]{1,4}_[^_]+$";
        if (username.length() <=5 && Pattern.matches(regex, username)) {
            return "Username successfully captured.";
        } else {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
    }

    public static String checkPassword(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        if (Pattern.matches(regex, password)) {
            return "Password successfully captured.";
        } else {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
    }

    public static String checkPhoneNumber(String phoneNumber) {
        String regex = "^0\\d{9}$";
        if (Pattern.matches(regex, phoneNumber)) {
            return "Phone number is valid.";
        } else {
            return "Invalid SA phone number.";
        }
    }
}

import java.util.Scanner;
import java.util.regex.Pattern;

public class AccountCreator {
    private static String savedUsername = "";
    private static String savedPassword = "";

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Create account
        createAccount(input);
        
        // Login prompt
        loginPrompt(input);

        input.close();
    }

    private static void createAccount(Scanner input) {
        String username = "";
        String password = "";
        String phoneNumber = "";

        // Loop until a valid username is entered
        while (true) {
            System.out.println("Enter username (1-4 letters followed by '_' and at least 1 more character): ");
            username = input.nextLine();
            String usernameValidation = checkUsername(username);
            System.out.println(usernameValidation);
            if (usernameValidation.startsWith("Username successfully")) {
                savedUsername = username; // Store username
                break;
            }
        }

        // Loop until a valid password is entered
        while (true) {
            System.out.println("Enter password (at least 8 characters, including an uppercase letter, a number, and a special character): ");
            password = input.nextLine();
            String passwordValidation = checkPassword(password);
            System.out.println(passwordValidation);
            if (passwordValidation.startsWith("Password successfully")) {
                savedPassword = password; // Store password
                break;
            }
        }

        // Loop until a valid phone number is entered
        while (true) {
            System.out.println("Enter phone number (10 digits starting with 0): ");
            phoneNumber = input.nextLine();
            String phoneValidation = checkPhoneNumber(phoneNumber);
            System.out.println(phoneValidation);
            if (phoneValidation.startsWith("Phone number is valid")) {
                break;
            }
        }

        // Account creation success message
        System.out.println("Account created successfully with the following details:");
        System.out.println("Username: " + savedUsername);
        // Consider hiding password in production
        System.out.println("Password: " + savedPassword);
        System.out.println("Phone number: " + phoneNumber);
    }

    private static void loginPrompt(Scanner input) {
        String usernameAttempt;
        String passwordAttempt;
        
        // Loop until valid login
        while (true) {
            System.out.println("Login to your account:");
            System.out.print("Enter username: ");
            usernameAttempt = input.nextLine();
            System.out.print("Enter password: ");
            passwordAttempt = input.nextLine();
            
            if (usernameAttempt.equals(savedUsername) && passwordAttempt.equals(savedPassword)) {
                System.out.println("Login successful. Welcome!");
                break; // Exit the loop on successful login
            } else {
                System.out.println("Invalid username or password. Please try again.");
            }
        }
    }

    public static String checkUsername(String username) {
        String regex = "^[a-zA-Z]{1,4}_[^_]+$"; // Username format
        if (Pattern.matches(regex, username)) {
            return "Username successfully captured.";
        } else {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and the pattern is 1-4 letters + '_' + at least 1 more character.";
        }
    }

    public static String checkPassword(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$"; // Password format
        if (Pattern.matches(regex, password)) {
            return "Password successfully captured.";
        } else {
            return "Password is not correctly formatted; ensure it has at least eight characters, one capital letter, one number, and one special character.";
        }
    }

    public static String checkPhoneNumber(String phoneNumber) {
        String regex = "^0(6|7|8)\\d{8}$"; // South African phone number format
        if (Pattern.matches(regex, phoneNumber)) {
            return "Phone number is valid.";
        } else {
            return "Invalid SA phone number; it should have 10 digits and start with '07, 06, or 08'.";
        }
    }
}

